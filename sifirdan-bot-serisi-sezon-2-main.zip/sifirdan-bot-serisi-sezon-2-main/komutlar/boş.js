const Discord = require("discord.js");
const db = require("nrc.db")
const ayarlar = require("../ayarlar.json")


module.exports = {
    calistir: async(client, message, args) => {



},

name: "test",
description: "",
aliases: [""],
kategori: "",
usage: "",
}